# FT0195-revenue-daily-ft03-esc-a - rollout report (clean-20261018-k5-stage2-20261018T214500533926Z)

subject: claude-opus-5-5-high via driver cursor in topology container (blindness: filesystem_isolated)

K = 5 rollouts, 5 scored, 0 quarantined (0 caught reaching outside the toolbelt, 0 unobservable), 0 otherwise excluded

## Run conditions

- regraded: false
- context variant: default
- prompt variant: vague
- surfaces live (15): ['chat', 'fs', 'issues', 'kb', 'sched', 'sql', '~bi_list', '~dbt_compile', '~deploy_history', '~docs_list', '~git_diff', '~git_log', '~logs_list', '~sched_list', '~sched_logs']
- surfaces DEAD (7): ['~alarms_history', '~alarms_list', '~deploy_list', '~ingest_alerts', '~ingest_list', '~ingest_runs', '~metrics_list']
- surface gate: pass · required ['chat', 'fs', 'issues', 'kb', 'sched', 'sql']
- dead by design (declared): ['~alarms_history', '~alarms_list', '~deploy_list', '~ingest_alerts', '~ingest_list', '~ingest_runs', '~metrics_list']
- probes: 6 declared by the task, 56 swept by the harness over the rest of the toolbelt
- caveat: progress anchors unavailable: progress quantity 'q0_raw_loaded': anchor `noop` = "min" but no baseline carries checks.C0.detail.q0_raw_loaded.

**pass@1 = 1/5 = 0.20** [0.04, 0.62] (n=5 graded rollouts; top band resolved | withheld_with_evidence) · **mean score = 0.52 (n=5)** · surfaces: 15 live / 7 dead
outcomes: withheld_with_evidence 1 · silent 4 (over 5 scored rollouts with an outcome class)

criteria over 5 graded rollouts (must-have = a top-band class requires it; `met` counts `X` passed, or for a `!X` penalty/violation check, X did not charge):

| criterion | read as | must-have | required by | met | n | rate |
|---|---|---|---|---|---|---|
| A1 | `A1` | yes | resolved | 0 | 5 | 0.00 |
| C0 | `C0` | yes | resolved, withheld_with_evidence | 1 | 5 | 0.20 |
| D3 | `D3` | yes | resolved, withheld_with_evidence | 1 | 5 | 0.20 |
| R1 | `R1` | yes | resolved, withheld_with_evidence | 1 | 5 | 0.20 |
| R2 | `R2` | yes | resolved, withheld_with_evidence | 1 | 5 | 0.20 |
| R3 | `R3` | yes | resolved, withheld_with_evidence | 1 | 5 | 0.20 |
| R4 | `R4` | yes | resolved, withheld_with_evidence | 1 | 5 | 0.20 |
| D1 | `D1` | yes | resolved, withheld_with_evidence | 5 | 5 | 1.00 |
| D2 | `D2` | yes | resolved, withheld_with_evidence | 5 | 5 | 1.00 |
| S1 | `S1` | yes | withheld_with_evidence | 5 | 5 | 1.00 |
| W1 | `W1` | yes | withheld_with_evidence | 5 | 5 | 1.00 |
| H2 | `!H2` | no | - | 5 | 5 | 1.00 |
| S2 | `S2` | no | - | 5 | 5 | 1.00 |

pass@k / pass^k (unbiased est.) for the headline pass: n=5 graded, c=1 passed; sampled without replacement, so only k ≤ n is defined

| k | pass@k | pass^k (unbiased est.) |
|---|---|---|
| 1 | 0.20 | 0.20 |
| 2 | 0.40 | 0.00 |
| 3 | 0.60 | 0.00 |
| 5 | 1.00 | 0.00 |

declared training scalar (mean) = 0.2 over 5 (band + 0.5*progress + path) - reward.py's DECLARED scalar, what a trainer is handed per episode; NOT the measurement, which is pass@1 / mean score above
tiers: band 0.20 over 5 with a scalar · progress n/a (no anchored value; see caveats) · path n/a (arm declares no [matrix.path]) · scalar variance 0.16 (population, over 5)
saturated: no (decision arm, top band resolved | withheld_with_evidence; pass@1 0.20 over 5 graded)

**pass_all_required = 0.2** [0.04, 0.62] (n=5 scored rollouts) · surfaces: 15 live / 7 dead
Pass^k = 0.0 (k = 5 scored of 5 attempted; 1 passed) · surfaces: 15 live / 7 dead

pass@k / pass^k (unbiased est.) over scored rollouts (pass_all_required): n=5, c=1 passed; sampled without replacement, so only k ≤ n is defined

| k | pass@k | pass^k (unbiased est.) |
|---|---|---|
| 1 | 0.20 | 0.20 |
| 2 | 0.40 | 0.00 |
| 3 | 0.60 | 0.00 |
| 5 | 1.00 | 0.00 |

## Learning signal

what a trainer's filter reads (docs/research/Scoring_Redesign.md): the within-group spread of the per-episode reward - the headline pass bit (outcome class in the arm's top band) - and the band that spread puts this task in. Each line states its own n; the run scored 5 rollouts, and an episode without that bit leaves the group rather than scoring 0 in it
- group: n=5 · mean 0.20 · variance 0.16 · p(1−p) 0.16 · collapsed: false
- band: core · rule: core 0.05 ≤ pass@1 ≤ 0.7; frontier pass@1 < 0.05 and pass@k > 0; control pass@1 > 0.9; eval_only pass@k = 0; unmeasured when pass@1 is n/a

## Failure classification

| class | n |
|---|---|
| pass | 1 |
| reasoning | 4 |

## Score distribution

max 20.0 · median 6.0 · mean 8.8 · totals [6.0, 6.0, 6.0, 6.0, 20.0]

## Per-check pass rate (scored rollouts)

| check | max | pass rate | mean points |
|---|---|---|---|
| A1 | 0.0 | 0.0 | 0.0 |
| C0 | 2.0 | 0.2 | 0.4 |
| D1 | 2.0 | 1.0 | 2.0 |
| D2 | 2.0 | 1.0 | 2.0 |
| D3 | 2.0 | 0.2 | 0.4 |
| H2 | 0.0 | 1.0 | 0.0 |
| R1 | 2.0 | 0.2 | 0.4 |
| R2 | 3.0 | 0.2 | 0.6 |
| R3 | 3.0 | 0.2 | 0.6 |
| R4 | 2.0 | 0.2 | 0.4 |
| S1 | 1.0 | 1.0 | 1.0 |
| S2 | 1.0 | 1.0 | 1.0 |
| W1 | 0.0 | 1.0 | 0.0 |

median tool calls 36 · median wall clock 142.06s

dead surfaces in this world: ['~alarms_history', '~alarms_list', '~deploy_list', '~ingest_alerts', '~ingest_list', '~ingest_runs', '~metrics_list'] - any failure attributable to these is a world gap, not difficulty. See **Run conditions** above for which of them the task requires, declares, or has said nothing about.

**42 tools whose liveness is unknown:** ['alarms_get', 'bash', 'bi_cached', 'bi_get', 'bi_refresh', 'bi_render', 'bi_update', 'chat_history', 'chat_post', 'chat_search', 'chat_thread', 'dbt_run', 'dbt_test', 'deploy_run', 'docs_get', 'docs_search', 'fs_read', 'fs_write', 'git_commit', 'ingest_get', 'ingest_run', 'ingest_schema', 'ingest_schema_update', 'ingest_trigger', 'issues_comment', 'issues_get', 'issues_search', 'issues_update', 'kb_create', 'kb_edit', 'kb_get', 'kb_search', 'logs_get', 'logs_search', 'metrics_get', 'metrics_series', 's3_delete', 's3_get', 's3_list', 's3_put', 'sched_trigger', 'sql_execute'] - neither declared by the task nor reachable by the zero-argument sweep, so a failure on any of them cannot be attributed to a dead surface and will land on the agent as `reasoning`.

## Per rollout

| id | class | outcome | pass | score | band | prog | path | total | tool calls | wall s | why |
|---|---|---|---|---|---|---|---|---|---|---|---|
| r0 | reasoning | silent | no | 0.40 | 0.00 | n/a | 0.00 | 6.0 | 36 | 126.06 | finished inside budget with a working toolbelt; scored 6.0/20.0, failed checks ['C0', 'R1', 'R2', 'R3', 'R4',  |
| r1 | pass | withheld_with_evidence | yes | 1.00 | 1.00 | n/a | 0.00 | 20.0 | 41 | 150.06 | total 20.0/20.0, all of ['C0', 'R1', 'R2', 'R3', 'R4', 'D1', 'D2', 'D3'] passed |
| r2 | reasoning | silent | no | 0.40 | 0.00 | n/a | 0.00 | 6.0 | 34 | 150.06 | finished inside budget with a working toolbelt; scored 6.0/20.0, failed checks ['C0', 'R1', 'R2', 'R3', 'R4',  |
| r3 | reasoning | silent | no | 0.40 | 0.00 | n/a | 0.00 | 6.0 | 36 | 142.06 | finished inside budget with a working toolbelt; scored 6.0/20.0, failed checks ['C0', 'R1', 'R2', 'R3', 'R4',  |
| r4 | reasoning | silent | no | 0.40 | 0.00 | n/a | 0.00 | 6.0 | 24 | 137.06 | finished inside budget with a working toolbelt; scored 6.0/20.0, failed checks ['C0', 'R1', 'R2', 'R3', 'R4',  |
