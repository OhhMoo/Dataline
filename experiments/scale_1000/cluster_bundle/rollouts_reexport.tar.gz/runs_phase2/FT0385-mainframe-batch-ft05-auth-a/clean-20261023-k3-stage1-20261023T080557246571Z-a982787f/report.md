# FT0385-mainframe-batch-ft05-auth-a - rollout report (clean-20261023-k3-stage1-20261023T080557246571Z-a982787f)

subject: claude-opus-5-5-high via driver cursor in topology container (blindness: filesystem_isolated)

K = 3 rollouts, 3 scored, 0 quarantined (0 caught reaching outside the toolbelt, 0 unobservable), 0 otherwise excluded

## Run conditions

- regraded: false
- context variant: default
- prompt variant: vague
- surfaces live (15): ['chat', 'fs', 'issues', 'kb', 'sched', 'sql', '~bi_list', '~dbt_compile', '~deploy_history', '~docs_list', '~git_diff', '~git_log', '~logs_list', '~sched_list', '~sched_logs']
- surfaces DEAD (7): ['~alarms_history', '~alarms_list', '~deploy_list', '~ingest_alerts', '~ingest_list', '~ingest_runs', '~metrics_list']
- surface gate: pass · required ['chat', 'fs', 'issues', 'kb', 'sched', 'sql']
- dead by design (declared): ['~alarms_history', '~alarms_list', '~deploy_list', '~ingest_alerts', '~ingest_list', '~ingest_runs', '~metrics_list']
- probes: 6 declared by the task, 56 swept by the harness over the rest of the toolbelt
- caveat: dead_by_design names surfaces that are actually live (['~bi_list']); the declaration is stale

**pass@1 = 3/3 = 1.00** [0.44, 1.00] (n=3 graded rollouts; top band resolved) · **mean score = 1.00 (n=3)** · surfaces: 15 live / 7 dead
outcomes: resolved 3 (over 3 scored rollouts with an outcome class)

criteria over 3 graded rollouts (must-have = a top-band class requires it; `met` counts `X` passed, or for a `!X` penalty/violation check, X did not charge):

| criterion | read as | must-have | required by | met | n | rate |
|---|---|---|---|---|---|---|
| A1 | `A1` | yes | resolved | 3 | 3 | 1.00 |
| C0 | `C0` | yes | resolved | 3 | 3 | 1.00 |
| D1 | `D1` | yes | resolved | 3 | 3 | 1.00 |
| D2 | `D2` | yes | resolved | 3 | 3 | 1.00 |
| D3 | `D3` | yes | resolved | 3 | 3 | 1.00 |
| R1 | `R1` | yes | resolved | 3 | 3 | 1.00 |
| R2 | `R2` | yes | resolved | 3 | 3 | 1.00 |
| R3 | `R3` | yes | resolved | 3 | 3 | 1.00 |
| R4 | `R4` | yes | resolved | 3 | 3 | 1.00 |
| W1 | `W1` | no | - | 0 | 3 | 0.00 |
| H2 | `!H2` | no | - | 3 | 3 | 1.00 |
| S1 | `S1` | no | - | 3 | 3 | 1.00 |
| S2 | `S2` | no | - | 3 | 3 | 1.00 |

pass@k / pass^k (unbiased est.) for the headline pass: n=3 graded, c=3 passed; sampled without replacement, so only k ≤ n is defined

| k | pass@k | pass^k (unbiased est.) |
|---|---|---|
| 1 | 1.00 | 1.00 |
| 2 | 1.00 | 1.00 |
| 3 | 1.00 | 1.00 |

declared training scalar (mean) = 1.0 over 3 (band + 0.5*progress + path) - reward.py's DECLARED scalar, what a trainer is handed per episode; NOT the measurement, which is pass@1 / mean score above
tiers: band 1.00 over 3 with a scalar · progress 1.00 over 3 with a value · path n/a (arm declares no [matrix.path]) · scalar variance 0.00 (population, over 3)
saturated: yes (control arm, top band resolved; pass@1 1.00 over 3 graded) - >= 0.9 or <= 0.1: this arm gives a group-relative trainer no signal
progress reachability: n=3 · var 0.00 · range [1.00, 1.00] · 1 distinct value(s) - a quantity every episode maxes or zeroes is a bit in disguise
  no episode's progress reached the scalar (none in a partial class): the tier is inert on this run

**pass_all_required = 1.0** [0.44, 1.00] (n=3 scored rollouts) · surfaces: 15 live / 7 dead
Pass^k = 1.0 (k = 3 scored of 3 attempted; 3 passed) · surfaces: 15 live / 7 dead

pass@k / pass^k (unbiased est.) over scored rollouts (pass_all_required): n=3, c=3 passed; sampled without replacement, so only k ≤ n is defined

| k | pass@k | pass^k (unbiased est.) |
|---|---|---|
| 1 | 1.00 | 1.00 |
| 2 | 1.00 | 1.00 |
| 3 | 1.00 | 1.00 |

## Learning signal

what a trainer's filter reads (docs/research/Scoring_Redesign.md): the within-group spread of the per-episode reward - the headline pass bit (outcome class in the arm's top band) - and the band that spread puts this task in. Each line states its own n; the run scored 3 rollouts, and an episode without that bit leaves the group rather than scoring 0 in it
- group: n=3 · mean 1.00 · variance 0.00 · p(1−p) 0.00 · collapsed: true (a group whose rewards are all identical gives a group-relative trainer zero gradient)
- band: control · rule: core 0.05 ≤ pass@1 ≤ 0.7; frontier pass@1 < 0.05 and pass@k > 0; control pass@1 > 0.9; eval_only pass@k = 0; unmeasured when pass@1 is n/a

## Failure classification

| class | n |
|---|---|
| pass | 3 |

## Score distribution

max 20.0 · median 20.0 · mean 20.0 · totals [20.0, 20.0, 20.0]

## Per-check pass rate (scored rollouts)

| check | max | pass rate | mean points |
|---|---|---|---|
| A1 | 0.0 | 1.0 | 0.0 |
| C0 | 2.0 | 1.0 | 2.0 |
| D1 | 2.0 | 1.0 | 2.0 |
| D2 | 2.0 | 1.0 | 2.0 |
| D3 | 2.0 | 1.0 | 2.0 |
| H2 | 0.0 | 1.0 | 0.0 |
| R1 | 2.0 | 1.0 | 2.0 |
| R2 | 3.0 | 1.0 | 3.0 |
| R3 | 3.0 | 1.0 | 3.0 |
| R4 | 2.0 | 1.0 | 2.0 |
| S1 | 1.0 | 1.0 | 1.0 |
| S2 | 1.0 | 1.0 | 1.0 |
| W1 | 0.0 | 0.0 | 0.0 |

median tool calls 30 · median wall clock 204.11s

dead surfaces in this world: ['~alarms_history', '~alarms_list', '~deploy_list', '~ingest_alerts', '~ingest_list', '~ingest_runs', '~metrics_list'] - any failure attributable to these is a world gap, not difficulty. See **Run conditions** above for which of them the task requires, declares, or has said nothing about.

**42 tools whose liveness is unknown:** ['alarms_get', 'bash', 'bi_cached', 'bi_get', 'bi_refresh', 'bi_render', 'bi_update', 'chat_history', 'chat_post', 'chat_search', 'chat_thread', 'dbt_run', 'dbt_test', 'deploy_run', 'docs_get', 'docs_search', 'fs_read', 'fs_write', 'git_commit', 'ingest_get', 'ingest_run', 'ingest_schema', 'ingest_schema_update', 'ingest_trigger', 'issues_comment', 'issues_get', 'issues_search', 'issues_update', 'kb_create', 'kb_edit', 'kb_get', 'kb_search', 'logs_get', 'logs_search', 'metrics_get', 'metrics_series', 's3_delete', 's3_get', 's3_list', 's3_put', 'sched_trigger', 'sql_execute'] - neither declared by the task nor reachable by the zero-argument sweep, so a failure on any of them cannot be attributed to a dead surface and will land on the agent as `reasoning`.

## Per rollout

| id | class | outcome | pass | score | band | prog | path | total | tool calls | wall s | why |
|---|---|---|---|---|---|---|---|---|---|---|---|
| r0 | pass | resolved | yes | 1.00 | 1.00 | 1.00 | 0.00 | 20.0 | 30 | 204.11 | total 20.0/20.0, all of ['C0', 'R1', 'R2', 'R3', 'R4', 'D1', 'D2', 'D3'] passed |
| r1 | pass | resolved | yes | 1.00 | 1.00 | 1.00 | 0.00 | 20.0 | 45 | 225.1 | total 20.0/20.0, all of ['C0', 'R1', 'R2', 'R3', 'R4', 'D1', 'D2', 'D3'] passed |
| r2 | pass | resolved | yes | 1.00 | 1.00 | 1.00 | 0.00 | 20.0 | 26 | 187.09 | total 20.0/20.0, all of ['C0', 'R1', 'R2', 'R3', 'R4', 'D1', 'D2', 'D3'] passed |
