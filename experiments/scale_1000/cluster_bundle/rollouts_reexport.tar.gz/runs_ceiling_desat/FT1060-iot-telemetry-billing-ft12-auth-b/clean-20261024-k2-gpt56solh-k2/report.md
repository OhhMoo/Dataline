# FT1060-iot-telemetry-billing-ft12-auth-b - rollout report (clean-20261024-k2-gpt56solh-k2)

subject: gpt-5.6-sol-high via driver cursor in topology container (blindness: filesystem_isolated)

K = 2 rollouts, 2 scored, 0 quarantined (0 caught reaching outside the toolbelt, 0 unobservable), 0 otherwise excluded

## Run conditions

- regraded: false
- context variant: default
- prompt variant: vague
- surfaces live (15): ['chat', 'fs', 'issues', 'kb', 'sched', 'sql', '~bi_list', '~dbt_compile', '~deploy_history', '~docs_list', '~git_diff', '~git_log', '~logs_list', '~sched_list', '~sched_logs']
- surfaces DEAD (7): ['~alarms_history', '~alarms_list', '~deploy_list', '~ingest_alerts', '~ingest_list', '~ingest_runs', '~metrics_list']
- surface gate: pass · required ['chat', 'fs', 'issues', 'kb', 'sched', 'sql']
- dead by design (declared): ['~alarms_history', '~alarms_list', '~deploy_list', '~ingest_alerts', '~ingest_list', '~ingest_runs', '~metrics_list']
- probes: 6 declared by the task, 56 swept by the harness over the rest of the toolbelt
- caveat: dead_by_design names surfaces that are actually live (['~bi_list']); the declaration is stale
- caveat: progress anchors unavailable: no baselines JSON given

**pass@1 = 1/2 = 0.50** [0.10, 0.91] (n=2 graded rollouts; top band resolved) · **mean score = 0.78 (n=2)** · surfaces: 15 live / 7 dead
outcomes: resolved 1 · acted_unresolved 1 (over 2 scored rollouts with an outcome class)

criteria over 2 graded rollouts (must-have = a top-band class requires it; `met` counts `X` passed, or for a `!X` penalty/violation check, X did not charge):

| criterion | read as | must-have | required by | met | n | rate |
|---|---|---|---|---|---|---|
| D3 | `D3` | yes | resolved | 1 | 2 | 0.50 |
| R2 | `R2` | yes | resolved | 1 | 2 | 0.50 |
| R3 | `R3` | yes | resolved | 1 | 2 | 0.50 |
| R4 | `R4` | yes | resolved | 1 | 2 | 0.50 |
| A1 | `A1` | yes | resolved | 2 | 2 | 1.00 |
| C0 | `C0` | yes | resolved | 2 | 2 | 1.00 |
| D1 | `D1` | yes | resolved | 2 | 2 | 1.00 |
| D2 | `D2` | yes | resolved | 2 | 2 | 1.00 |
| R1 | `R1` | yes | resolved | 2 | 2 | 1.00 |
| W1 | `W1` | no | - | 0 | 2 | 0.00 |
| H2 | `!H2` | no | - | 2 | 2 | 1.00 |
| S1 | `S1` | no | - | 2 | 2 | 1.00 |
| S2 | `S2` | no | - | 2 | 2 | 1.00 |

pass@k / pass^k (unbiased est.) for the headline pass: n=2 graded, c=1 passed; sampled without replacement, so only k ≤ n is defined

| k | pass@k | pass^k (unbiased est.) |
|---|---|---|
| 1 | 0.50 | 0.50 |
| 2 | 1.00 | 0.00 |

declared training scalar (mean) = 0.5 over 2 (band + 0.5*progress + path) - reward.py's DECLARED scalar, what a trainer is handed per episode; NOT the measurement, which is pass@1 / mean score above
tiers: band 0.50 over 2 with a scalar · progress n/a (no anchored value; see caveats) · path n/a (arm declares no [matrix.path]) · scalar variance 0.25 (population, over 2)
saturated: no (control arm, top band resolved; pass@1 0.50 over 2 graded)

**pass_all_required = 0.5** [0.10, 0.91] (n=2 scored rollouts) · surfaces: 15 live / 7 dead
Pass^k = 0.0 (k = 2 scored of 2 attempted; 1 passed) · surfaces: 15 live / 7 dead

pass@k / pass^k (unbiased est.) over scored rollouts (pass_all_required): n=2, c=1 passed; sampled without replacement, so only k ≤ n is defined

| k | pass@k | pass^k (unbiased est.) |
|---|---|---|
| 1 | 0.50 | 0.50 |
| 2 | 1.00 | 0.00 |

## Learning signal

what a trainer's filter reads (docs/research/Scoring_Redesign.md): the within-group spread of the per-episode reward - the headline pass bit (outcome class in the arm's top band) - and the band that spread puts this task in. Each line states its own n; the run scored 2 rollouts, and an episode without that bit leaves the group rather than scoring 0 in it
- group: n=2 · mean 0.50 · variance 0.25 · p(1−p) 0.25 · collapsed: false
- band: core · rule: core 0.05 ≤ pass@1 ≤ 0.7; frontier pass@1 < 0.05 and pass@k > 0; control pass@1 > 0.9; eval_only pass@k = 0; unmeasured when pass@1 is n/a

## Failure classification

| class | n |
|---|---|
| pass | 1 |
| reasoning | 1 |

## Score distribution

max 20.0 · median 15.0 · mean 15.0 · totals [10.0, 20.0]

## Per-check pass rate (scored rollouts)

| check | max | pass rate | mean points |
|---|---|---|---|
| A1 | 0.0 | 1.0 | 0.0 |
| C0 | 2.0 | 1.0 | 2.0 |
| D1 | 2.0 | 1.0 | 2.0 |
| D2 | 2.0 | 1.0 | 2.0 |
| D3 | 2.0 | 0.5 | 1.0 |
| H2 | 0.0 | 1.0 | 0.0 |
| R1 | 2.0 | 1.0 | 2.0 |
| R2 | 3.0 | 0.5 | 1.5 |
| R3 | 3.0 | 0.5 | 1.5 |
| R4 | 2.0 | 0.5 | 1.0 |
| S1 | 1.0 | 1.0 | 1.0 |
| S2 | 1.0 | 1.0 | 1.0 |
| W1 | 0.0 | 0.0 | 0.0 |

median tool calls 112.0 · median wall clock 228.89s

dead surfaces in this world: ['~alarms_history', '~alarms_list', '~deploy_list', '~ingest_alerts', '~ingest_list', '~ingest_runs', '~metrics_list'] - any failure attributable to these is a world gap, not difficulty. See **Run conditions** above for which of them the task requires, declares, or has said nothing about.

**42 tools whose liveness is unknown:** ['alarms_get', 'bash', 'bi_cached', 'bi_get', 'bi_refresh', 'bi_render', 'bi_update', 'chat_history', 'chat_post', 'chat_search', 'chat_thread', 'dbt_run', 'dbt_test', 'deploy_run', 'docs_get', 'docs_search', 'fs_read', 'fs_write', 'git_commit', 'ingest_get', 'ingest_run', 'ingest_schema', 'ingest_schema_update', 'ingest_trigger', 'issues_comment', 'issues_get', 'issues_search', 'issues_update', 'kb_create', 'kb_edit', 'kb_get', 'kb_search', 'logs_get', 'logs_search', 'metrics_get', 'metrics_series', 's3_delete', 's3_get', 's3_list', 's3_put', 'sched_trigger', 'sql_execute'] - neither declared by the task nor reachable by the zero-argument sweep, so a failure on any of them cannot be attributed to a dead surface and will land on the agent as `reasoning`.

## Per rollout

| id | class | outcome | pass | score | band | prog | path | total | tool calls | wall s | why |
|---|---|---|---|---|---|---|---|---|---|---|---|
| r0 | reasoning | acted_unresolved | no | 0.56 | 0.00 | n/a | 0.00 | 10.0 | 99 | 205.17 | finished inside budget with a working toolbelt; scored 10.0/20.0, failed checks ['R2', 'R3', 'R4', 'D3', 'W1'] |
| r1 | pass | resolved | yes | 1.00 | 1.00 | n/a | 0.00 | 20.0 | 125 | 252.62 | total 20.0/20.0, all of ['C0', 'R1', 'R2', 'R3', 'R4', 'D1', 'D2', 'D3'] passed |
