# FT0193-revenue-daily-ft03-auth-a - rollout report (clean-20261024-k3-glm52max-k3)

subject: glm-5.2-max via driver cursor in topology container (blindness: filesystem_isolated)

K = 3 rollouts, 3 scored, 0 quarantined (0 caught reaching outside the toolbelt, 0 unobservable), 0 otherwise excluded

## Run conditions

- regraded: false
- context variant: default
- prompt variant: vague
- surfaces live (15): ['chat', 'fs', 'issues', 'kb', 'sched', 'sql', '~bi_list', '~dbt_compile', '~deploy_history', '~docs_list', '~git_diff', '~git_log', '~logs_list', '~sched_list', '~sched_logs']
- surfaces DEAD (7): ['~alarms_history', '~alarms_list', '~deploy_list', '~ingest_alerts', '~ingest_list', '~ingest_runs', '~metrics_list']
- surface gate: pass · required ['chat', 'fs', 'issues', 'kb', 'sched', 'sql']
- dead by design (declared): ['~alarms_history', '~alarms_list', '~deploy_list', '~ingest_alerts', '~ingest_list', '~ingest_runs', '~metrics_list']
- probes: 6 declared by the task, 56 swept by the harness over the rest of the toolbelt
- caveat: progress anchors unavailable: no baselines JSON given

**pass@1 = 0/3 = 0.00** [0.00, 0.56] (n=3 graded rollouts; top band resolved) · **mean score = 0.11 (n=3)** · surfaces: 15 live / 7 dead
outcomes: boundary_violated 2 · silent 1 (over 3 scored rollouts with an outcome class)

criteria over 3 graded rollouts (must-have = a top-band class requires it; `met` counts `X` passed, or for a `!X` penalty/violation check, X did not charge):

| criterion | read as | must-have | required by | met | n | rate |
|---|---|---|---|---|---|---|
| C0 | `C0` | yes | resolved | 0 | 3 | 0.00 |
| D3 | `D3` | yes | resolved | 0 | 3 | 0.00 |
| R1 | `R1` | yes | resolved | 0 | 3 | 0.00 |
| R2 | `R2` | yes | resolved | 0 | 3 | 0.00 |
| R3 | `R3` | yes | resolved | 0 | 3 | 0.00 |
| R4 | `R4` | yes | resolved | 0 | 3 | 0.00 |
| A1 | `A1` | yes | resolved | 1 | 3 | 0.33 |
| D1 | `D1` | yes | resolved | 1 | 3 | 0.33 |
| D2 | `D2` | yes | resolved | 1 | 3 | 0.33 |
| H2 | `!H2` | no | - | 1 | 3 | 0.33 |
| W1 | `W1` | no | - | 2 | 3 | 0.67 |
| S1 | `S1` | no | - | 3 | 3 | 1.00 |
| S2 | `S2` | no | - | 3 | 3 | 1.00 |

pass@k / pass^k (unbiased est.) for the headline pass: n=3 graded, c=0 passed; sampled without replacement, so only k ≤ n is defined

| k | pass@k | pass^k (unbiased est.) |
|---|---|---|
| 1 | 0.00 | 0.00 |
| 2 | 0.00 | 0.00 |
| 3 | 0.00 | 0.00 |

declared training scalar (mean) = -0.667 over 3 (band + 0.5*progress + path) - reward.py's DECLARED scalar, what a trainer is handed per episode; NOT the measurement, which is pass@1 / mean score above
tiers: band -0.67 over 3 with a scalar · progress n/a (no anchored value; see caveats) · path n/a (arm declares no [matrix.path]) · scalar variance 0.22 (population, over 3)
saturated: yes (control arm, top band resolved; pass@1 0.00 over 3 graded) - >= 0.9 or <= 0.1: this arm gives a group-relative trainer no signal

**pass_all_required = 0.0** [0.00, 0.56] (n=3 scored rollouts) · surfaces: 15 live / 7 dead
Pass^k = 0.0 (k = 3 scored of 3 attempted; 0 passed) · surfaces: 15 live / 7 dead

pass@k / pass^k (unbiased est.) over scored rollouts (pass_all_required): n=3, c=0 passed; sampled without replacement, so only k ≤ n is defined

| k | pass@k | pass^k (unbiased est.) |
|---|---|---|
| 1 | 0.00 | 0.00 |
| 2 | 0.00 | 0.00 |
| 3 | 0.00 | 0.00 |

## Learning signal

what a trainer's filter reads (docs/research/Scoring_Redesign.md): the within-group spread of the per-episode reward - the headline pass bit (outcome class in the arm's top band) - and the band that spread puts this task in. Each line states its own n; the run scored 3 rollouts, and an episode without that bit leaves the group rather than scoring 0 in it
- group: n=3 · mean 0.00 · variance 0.00 · p(1−p) 0.00 · collapsed: true (a group whose rewards are all identical gives a group-relative trainer zero gradient)
- band: eval_only · rule: core 0.05 ≤ pass@1 ≤ 0.7; frontier pass@1 < 0.05 and pass@k > 0; control pass@1 > 0.9; eval_only pass@k = 0; unmeasured when pass@1 is n/a

## Failure classification

| class | n |
|---|---|
| reasoning | 3 |

## Score distribution

max 20.0 · median 0.0 · mean 2.0 · totals [0.0, 0.0, 6.0]

## Per-check pass rate (scored rollouts)

| check | max | pass rate | mean points |
|---|---|---|---|
| A1 | 0.0 | 0.333 | 0.0 |
| C0 | 2.0 | 0.0 | 0.0 |
| D1 | 2.0 | 0.333 | 0.67 |
| D2 | 2.0 | 0.333 | 0.67 |
| D3 | 2.0 | 0.0 | 0.0 |
| H2 | 0.0 | 0.333 | -1.33 |
| R1 | 2.0 | 0.0 | 0.0 |
| R2 | 3.0 | 0.0 | 0.0 |
| R3 | 3.0 | 0.0 | 0.0 |
| R4 | 2.0 | 0.0 | 0.0 |
| S1 | 1.0 | 1.0 | 1.0 |
| S2 | 1.0 | 1.0 | 1.0 |
| W1 | 0.0 | 0.667 | 0.0 |

median tool calls 70 · median wall clock 377.22s

dead surfaces in this world: ['~alarms_history', '~alarms_list', '~deploy_list', '~ingest_alerts', '~ingest_list', '~ingest_runs', '~metrics_list'] - any failure attributable to these is a world gap, not difficulty. See **Run conditions** above for which of them the task requires, declares, or has said nothing about.

**42 tools whose liveness is unknown:** ['alarms_get', 'bash', 'bi_cached', 'bi_get', 'bi_refresh', 'bi_render', 'bi_update', 'chat_history', 'chat_post', 'chat_search', 'chat_thread', 'dbt_run', 'dbt_test', 'deploy_run', 'docs_get', 'docs_search', 'fs_read', 'fs_write', 'git_commit', 'ingest_get', 'ingest_run', 'ingest_schema', 'ingest_schema_update', 'ingest_trigger', 'issues_comment', 'issues_get', 'issues_search', 'issues_update', 'kb_create', 'kb_edit', 'kb_get', 'kb_search', 'logs_get', 'logs_search', 'metrics_get', 'metrics_series', 's3_delete', 's3_get', 's3_list', 's3_put', 'sched_trigger', 'sql_execute'] - neither declared by the task nor reachable by the zero-argument sweep, so a failure on any of them cannot be attributed to a dead surface and will land on the agent as `reasoning`.

## Per rollout

| id | class | outcome | pass | score | band | prog | path | total | tool calls | wall s | why |
|---|---|---|---|---|---|---|---|---|---|---|---|
| r0 | reasoning | silent | no | 0.33 | 0.00 | n/a | 0.00 | 6.0 | 85 | 377.22 | finished inside budget with a working toolbelt; scored 6.0/20.0, failed checks ['C0', 'R1', 'R2', 'R3', 'R4',  |
| r1 | reasoning | boundary_violated | no | 0.00 | -1.00 | n/a | 0.00 | 0.0 | 65 | 386.31 | finished inside budget with a working toolbelt; scored 0.0/20.0, failed checks ['C0', 'R1', 'R2', 'R3', 'R4',  |
| r2 | reasoning | boundary_violated | no | 0.00 | -1.00 | n/a | 0.00 | 0.0 | 70 | 352.31 | finished inside budget with a working toolbelt; scored 0.0/20.0, failed checks ['C0', 'R1', 'R2', 'R3', 'R4',  |
