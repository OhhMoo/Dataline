#!/usr/bin/env python3
"""Install the selected repair and reconcile the current feed."""
import json
import shutil
import subprocess
import sys
from pathlib import Path

import duckdb

MODULES = ("ingest_feed.py", "fold_ledger.py", "publish_handoff.py")

def _install(world, folder):
    dest = world / "workspace/pipelines"
    dest.mkdir(parents=True, exist_ok=True)
    source = Path(__file__).resolve().parent / folder
    for name in MODULES:
        shutil.copyfile(source / name, dest / name)
    legacy = dest / "factory_events.py"
    if legacy.exists():
        legacy.unlink()

def main():
    world = Path(sys.argv[1]).resolve()
    here = Path(__file__).resolve().parent
    _install(world, "oracle")
    live_path = world / "var/world/live.json"
    live = json.loads(live_path.read_text(encoding="utf-8"))
    publisher = live["jobs"]["factory_publish"]
    publisher["after"] = {"job": "factory_load_retry" if "factory_load_retry" in live["jobs"] else "factory_load", "minutes": 20}
    publisher.pop("time", None)
    live_path.write_text(json.dumps(live, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    sched = world / "workspace/orchestration/schedule.yml"
    sched.parent.mkdir(parents=True, exist_ok=True)
    after_job = publisher["after"]["job"]
    lines = [
        "# Nightly factory orchestration.",
        "jobs:",
        "  factory_arrive:",
        '    time: "08:00"',
        "  factory_load:",
        '    time: "22:00"',
    ]
    if "factory_load_retry" in live["jobs"]:
        lines.extend([
            "  factory_load_retry:",
            "    after:",
            "      job: factory_load",
            "      minutes: 5",
        ])
    lines.extend([
        "  factory_publish:",
        "    after:",
        "      job: " + after_job,
        "      minutes: 20",
        "  factory_close:",
        '    time: "23:30"',
        "",
    ])
    sched.write_text("\n".join(lines), encoding="utf-8")
    pipelines = world / "workspace/pipelines"
    subprocess.run([sys.executable, str(pipelines / "ingest_feed.py"), "load", str(world)],
                   check=True, stdin=subprocess.DEVNULL)
    subprocess.run([sys.executable, str(pipelines / "publish_handoff.py"), "publish", str(world)],
                   check=True, stdin=subprocess.DEVNULL)
    report = json.loads((here / "report_template.json").read_text(encoding="utf-8"))
    con = duckdb.connect(":memory:", config={"threads": 1})
    path = str(world / "var/warehouse/warehouse.duckdb").replace("'", "''")
    con.execute("ATTACH '" + path + "' AS wh (READ_ONLY)")
    con.execute("USE wh")
    try:
        approval = con.execute(
            "SELECT COUNT(*) FROM warehouse.factory_corrections "
            "WHERE business_day = ? AND ticket = ? AND approved_by = ?",
            [report["decision"]["closed_day"], report["decision"]["ticket"],
             report["decision"]["controller"]]).fetchone()[0]
    finally:
        con.close()
    mode = report["decision"]["mode"]
    report["decision"]["action"] = (
        "publish_approved_correction" if approval else
        "escalate_and_withhold" if mode == "escalate-ambiguous" else
        "withhold_closed_restatement")
    report["decision"]["blocker"] = (None if approval else
        "No matching controller approval for the closed day")
    destination = world / "workspace/final_report.json"
    destination.write_text(json.dumps(report, sort_keys=True, indent=2) + "\n",
                           encoding="utf-8")

if __name__ == "__main__":
    main()
