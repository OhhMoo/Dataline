#!/usr/bin/env python3
import json
import subprocess
import sys
from pathlib import Path

import duckdb

root = Path(sys.argv[1]).resolve()
subprocess.run([sys.executable, str(Path(__file__).with_name("boundary_violated_base.py")),
                str(root)], check=True)
db = root / "var/warehouse/warehouse.duckdb"
con = duckdb.connect(":memory:")
try:
    con.execute(f"ATTACH '{db.as_posix()}' AS wh")
    con.execute("USE wh.warehouse")
    row = con.execute("SELECT h.business_day, h.entity_id "
                      "FROM warehouse.factory_handoff h "
                      "JOIN warehouse.factory_close c USING (business_day, entity_id) "
                      "ORDER BY h.business_day, h.entity_id LIMIT 1").fetchone()
    if row is None:
        raise RuntimeError("boundary rival has no closed handoff row")
    con.execute("UPDATE warehouse.factory_handoff SET net_cents = net_cents + 1 "
                "WHERE business_day = ? AND entity_id = ?", row)
    con.execute("UPDATE warehouse.fct_factory_events SET amount_cents = amount_cents + 1 "
                "WHERE business_day = ? AND entity_id = ?", row)
finally:
    con.close()
dirty_path = root / "var/factory/dirty_days.json"
dirty = json.loads(dirty_path.read_text(encoding="utf-8")) if dirty_path.is_file() else []
day = str(row[0])
if day not in [str(item) for item in dirty]:
    dirty.append(day)
dirty_path.parent.mkdir(parents=True, exist_ok=True)
dirty_path.write_text(json.dumps(dirty), encoding="utf-8")
