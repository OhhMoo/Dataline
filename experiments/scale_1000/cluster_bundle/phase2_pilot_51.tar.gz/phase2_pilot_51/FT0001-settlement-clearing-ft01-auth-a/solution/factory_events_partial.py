"""Partial modules are in the partial directory beside this file."""
