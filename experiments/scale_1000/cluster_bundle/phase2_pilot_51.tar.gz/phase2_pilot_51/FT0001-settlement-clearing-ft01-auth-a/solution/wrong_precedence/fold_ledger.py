#!/usr/bin/env python3
"""Fold raw partner events into the current fact table."""
import json
import sys
from pathlib import Path

import duckdb

RAW_TABLE = "raw.factory_events"
FACT_TABLE = "warehouse.fct_factory_events"


def db(root):
    con = duckdb.connect(":memory:", config={"threads": 1})
    path = str(root / "var/warehouse/warehouse.duckdb").replace("'", "''")
    con.execute("ATTACH '" + path + "' AS wh")
    con.execute("USE wh")
    return con


def fold(root):
    con = db(root)
    touched_path = root / "var/factory/touched.json"
    try:
        events = con.execute(
            "SELECT event_id, delivered_at, business_day, business_id, version, "
            "event_type, entity_id, amount_cents, source_partition FROM " + RAW_TABLE
        ).fetchall()
        latest = {}
        for event in events:
            key = event[3]
            order = (event[1], event[0], event[4])
            if key not in latest or order > latest[key][0]:
                latest[key] = (order, event)
        selected = [value[1] for value in latest.values()]
        con.execute("BEGIN TRANSACTION")
        con.execute("DELETE FROM warehouse.fct_factory_events")
        rows = []
        for event in selected:
            _event_id, _delivered, day, key, version, kind, entity, amount, _source = event
            if kind == "void":
                continue
            rows.append((key, day, entity, amount, version))
        if rows:
            con.executemany(
                "INSERT INTO " + FACT_TABLE +
                " (business_id, business_day, entity_id, amount_cents, version) "
                "VALUES (?, ?, ?, ?, ?)",
                rows)
        con.execute("COMMIT")
        print(f"fold: {len(rows)} current rows")
    except Exception:
        try:
            con.execute("ROLLBACK")
        except duckdb.Error:
            pass
        raise
    finally:
        con.close()


def main():
    action, root = sys.argv[1], Path(sys.argv[2])
    if action != "fold":
        raise SystemExit(f"unknown action: {action}")
    fold(root)


if __name__ == "__main__":
    main()
