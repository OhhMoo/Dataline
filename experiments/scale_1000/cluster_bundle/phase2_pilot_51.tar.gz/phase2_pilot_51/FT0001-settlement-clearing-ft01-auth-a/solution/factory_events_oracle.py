"""Repaired modules are in the oracle directory beside this file."""
