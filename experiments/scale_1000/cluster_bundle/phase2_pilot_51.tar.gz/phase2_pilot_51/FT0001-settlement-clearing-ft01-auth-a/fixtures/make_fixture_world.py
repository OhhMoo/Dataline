#!/usr/bin/env python3
"""Build a fresh theme world and stage the factory sidecar for one episode."""
import argparse
import json
import sys
from pathlib import Path
sys.path.insert(0, "/home/ubuntu/env_project")
from tasks.factory.compiler.peer_materializer import build_world_from_task
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path)
    parser.add_argument("--grading", type=Path)
    parser.add_argument("--seed", type=int)
    parser.add_argument("--prepare-only", action="store_true")
    args = parser.parse_args()
    if args.prepare_only:
        print(json.dumps({"prepared": True}))
        return
    if args.root is None or args.grading is None or args.seed is None:
        parser.error("--root, --grading and --seed are required")
    print(json.dumps(build_world_from_task(Path(__file__).resolve().parents[1],
                                          args.root, args.grading, args.seed), sort_keys=True))
if __name__ == "__main__":
    main()
