#!/usr/bin/env python3
"""Thin wrapper around the declarative factory grader."""
import sys
sys.path.insert(0, "/home/ubuntu/env_project")
from tasks.factory.grader.declarative_grade import main
if __name__ == "__main__":
    raise SystemExit(main())
