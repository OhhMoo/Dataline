#!/usr/bin/env python3
"""Stage the five canonical worlds and score them.

The verifier is tasks.factory.grader.baseline_runner. This script only builds
the worlds that runner expects and delegates scoring to it.
"""
import argparse
import json
import sys
from pathlib import Path
sys.path.insert(0, "/home/ubuntu/env_project")
from tasks.factory.compiler.peer_materializer import run_baselines_for_task
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scratch", type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    task = Path(__file__).resolve().parents[1]
    scratch = args.scratch or Path("/home/ubuntu/alkera_factory_1017/baselines") / task.name
    result = run_baselines_for_task(task, scratch)
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"task": result["task"], "valid": result["valid"]}))
    return 0 if result["valid"] else 1
if __name__ == "__main__":
    raise SystemExit(main())
