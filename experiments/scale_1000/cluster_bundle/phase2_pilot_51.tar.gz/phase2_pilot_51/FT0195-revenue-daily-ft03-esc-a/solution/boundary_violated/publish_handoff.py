#!/usr/bin/env python3
"""Publish the open window and freeze closed days."""
import json
import sys
from datetime import date, timedelta
from pathlib import Path

import duckdb

FACT_TABLE = "warehouse.fct_factory_events"
HANDOFF_TABLE = "warehouse.factory_handoff"
CLOSE_TABLE = "warehouse.factory_close"
CORRECTIONS_TABLE = "warehouse.factory_corrections"


def db(root):
    con = duckdb.connect(":memory:", config={"threads": 1})
    path = str(root / "var/warehouse/warehouse.duckdb").replace("'", "''")
    con.execute("ATTACH '" + path + "' AS wh")
    con.execute("USE wh")
    return con


def night(root):
    path = root / "var/factory/night.txt"
    return int(path.read_text(encoding="utf-8")) if path.exists() else 0


def publish(root):
    con = db(root)
    try:
        dirty_path = root / "var/factory/dirty_days.json"
        dirty_days = set(json.loads(dirty_path.read_text(encoding="utf-8"))
                         if dirty_path.is_file() else [])
        desired = {}
        for day, entity, count, total in con.execute(
                "SELECT business_day, entity_id, COUNT(*), SUM(amount_cents) "
                "FROM " + FACT_TABLE + " GROUP BY 1, 2").fetchall():
            desired.setdefault(str(day), {})[entity] = (int(count), int(total))
        current = {}
        for day, entity, count, total in con.execute(
                "SELECT business_day, entity_id, payments, net_cents FROM " + HANDOFF_TABLE
        ).fetchall():
            current.setdefault(str(day), {})[entity] = (int(count), int(total))
        frozen = {}
        for day, entity, count, total in con.execute(
                "SELECT business_day, entity_id, payments, net_cents FROM " + CLOSE_TABLE
        ).fetchall():
            frozen.setdefault(str(day), {})[entity] = (int(count), int(total))
        approved = {str(day): ticket for day, ticket in con.execute(
            "SELECT business_day, ticket FROM " + CORRECTIONS_TABLE).fetchall()}
        con.execute("BEGIN TRANSACTION")
        for day in sorted(set(desired) | set(current) | set(frozen)):
            want = desired.get(day, {})
            have = current.get(day, {})
            if day in frozen and day not in approved and day not in dirty_days:
                want = frozen[day]
                ref = None
            else:
                ref = approved.get(day)
            if want == have:
                continue
            con.execute("DELETE FROM " + HANDOFF_TABLE + " WHERE business_day = ?", [day])
            for entity, (count, total) in sorted(want.items(), key=lambda item: str(item[0])):
                con.execute(
                    "INSERT INTO " + HANDOFF_TABLE +
                    " (business_day, entity_id, payments, net_cents, correction_ref) "
                    "VALUES (?, ?, ?, ?, ?)",
                    [day, entity, count, total, ref])
        con.execute("COMMIT")
    except Exception:
        try:
            con.execute("ROLLBACK")
        except duckdb.Error:
            pass
        raise
    finally:
        con.close()


def close(root):
    n = night(root)
    if not n:
        return
    start = date.fromisoformat(json.loads(
        (root / "var/factory/config.json").read_text(encoding="utf-8"))["t0_day"])
    day = start + timedelta(days=n - 1)
    with db(root) as con:
        con.execute("DELETE FROM " + CLOSE_TABLE + " WHERE business_day = ?", [day])
        con.execute(
            "INSERT INTO " + CLOSE_TABLE +
            " (business_day, entity_id, payments, net_cents) "
            "SELECT business_day, entity_id, payments, net_cents FROM " + HANDOFF_TABLE +
            " WHERE business_day = ?",
            [day])


def main():
    action, root = sys.argv[1], Path(sys.argv[2])
    if action == "publish":
        publish(root)
    elif action == "close":
        close(root)
    else:
        raise SystemExit(f"unknown action: {action}")


if __name__ == "__main__":
    main()
