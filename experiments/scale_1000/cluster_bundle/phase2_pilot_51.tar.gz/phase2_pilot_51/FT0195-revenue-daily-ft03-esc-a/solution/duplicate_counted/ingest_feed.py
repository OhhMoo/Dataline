#!/usr/bin/env python3
"""Read partner landing files into the raw feed table."""
import csv
import json
import shutil
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import duckdb

FIELDS = ["event_id", "delivered_at", "business_day", "business_id",
          "version", "event_type", "entity_id", "amount_cents"]
FEED_REL = "data/factory_feed"
RAW_TABLE = "raw.factory_events"
CHECKPOINT_TABLE = "warehouse.factory_checkpoint"
CORRECTIONS_TABLE = "warehouse.factory_corrections"


def db(root):
    con = duckdb.connect(":memory:", config={"threads": 1})
    path = str(root / "var/warehouse/warehouse.duckdb").replace("'", "''")
    con.execute("ATTACH '" + path + "' AS wh")
    con.execute("USE wh")
    return con


def night(root):
    path = root / "var/factory/night.txt"
    return int(path.read_text(encoding="utf-8")) if path.exists() else 0


def arrival(root):
    n = night(root) + 1
    source = root / "build/factory_future" / f"R{n}"
    if not source.is_dir():
        return
    feed = root / "workspace" / FEED_REL
    for path in sorted(source.rglob("*")):
        if not path.is_file() or path.name == "_approvals.csv":
            continue
        dest = feed / path.relative_to(source)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, dest)
    approvals = source / "_approvals.csv"
    if approvals.is_file():
        with db(root) as con, approvals.open(newline="", encoding="utf-8") as handle:
            for row in csv.DictReader(handle):
                con.execute(
                    "INSERT INTO " + CORRECTIONS_TABLE +
                    " (business_day, ticket, approved_by) VALUES (?, ?, ?)",
                    [row["business_day"], row["ticket"], row["approved_by"]])
    stamp = root / "var/factory/night.txt"
    stamp.parent.mkdir(parents=True, exist_ok=True)
    stamp.write_text(str(n), encoding="utf-8")


def _parsed_time(value):
    moment = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    return moment.replace(tzinfo=None)

def _version(raw):
    return int(raw)

def _files(root, through, *, retry=False):
    feed = root / "workspace" / FEED_REL
    if not feed.is_dir():
        return
    for folder in sorted(feed.glob("dt=*")):
        if not folder.is_dir():
            continue
        day = folder.name.split("=", 1)[1]

        if not (day > through or (retry and day == through)):
            continue

        for path in sorted(folder.iterdir()):
            if not path.is_file():
                continue
            if path.name.endswith(".csv") or path.name.endswith(".csv.part"):
                yield day, path



def _read_rows(path):
    with path.open(encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)

        if list(reader.fieldnames or []) != FIELDS:
            raise ValueError(f"unexpected columns in {path.name}: {reader.fieldnames}")
        return list(reader)

def _row(row, source):
    moment = _parsed_time(row["delivered_at"])
    business_day = row.get("business_day") or ""
    if not str(business_day).strip():
        business_day = (moment.date() + timedelta(days=1)
                        if (moment.hour, moment.minute) >= (23, 30)
                        else moment.date()).isoformat()
    entity = row.get("entity_id") or None
    return (row["event_id"], moment, business_day, row["business_id"], _version(row.get("version")),
            row["event_type"], entity, int(row["amount_cents"]), source)


def _load_raw(root, *, retry=False):
    con = db(root)
    try:
        through = str(con.execute(
            "SELECT COALESCE(MAX(through_day), DATE '1970-01-01') FROM " + CHECKPOINT_TABLE
        ).fetchone()[0])
        files = list(_files(root, through, retry=retry))
        incoming = []
        for day, path in files:
            records = _read_rows(path)

            if not records:
                raise ValueError(f"empty feed file: {path.name}")
            incoming.extend(_row(row, str(path.relative_to(root / "workspace"))) for row in records)
        con.execute("BEGIN TRANSACTION")
        if incoming:
            con.executemany(
                "INSERT INTO " + RAW_TABLE + " (event_id, delivered_at, business_day, "
                "business_id, version, event_type, entity_id, amount_cents, source_partition) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                incoming)
        days = [day for day, _path in files]
        read_through = max(days + [through])
        con.execute("DELETE FROM " + CHECKPOINT_TABLE)
        con.execute("INSERT INTO " + CHECKPOINT_TABLE + " (through_day) VALUES (?)", [read_through])
        con.execute("COMMIT")
        state = root / "var/factory"
        state.mkdir(parents=True, exist_ok=True)
        touched = sorted({row[3] for row in incoming})
        dirty = sorted({str(row[2]) for row in incoming})
        (state / "touched.json").write_text(json.dumps(touched), encoding="utf-8")
        (state / "dirty_days.json").write_text(json.dumps(dirty), encoding="utf-8")
        print(f"ingest: {len(files)} files, {len(incoming)} rows")
    except Exception:
        try:
            con.execute("ROLLBACK")
        except duckdb.Error:
            pass
        raise
    finally:
        con.close()


def _fold(root):
    script = Path(__file__).resolve().with_name("fold_ledger.py")
    subprocess.run([sys.executable, str(script), "fold", str(root)],
                   check=True, stdin=subprocess.DEVNULL)


def load(root, *, retry=False):
    _load_raw(root, retry=retry)
    _fold(root)


def main():
    action, root = sys.argv[1], Path(sys.argv[2])
    if action == "arrive":
        arrival(root)
    elif action == "load":
        load(root)
    elif action == "retry":
        if night(root) == 2:
            load(root, retry=True)
    else:
        raise SystemExit(f"unknown action: {action}")


if __name__ == "__main__":
    main()
